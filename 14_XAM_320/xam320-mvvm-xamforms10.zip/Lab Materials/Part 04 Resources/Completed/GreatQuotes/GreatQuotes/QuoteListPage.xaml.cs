﻿using Xamarin.Forms;

namespace GreatQuotes
{
	public partial class QuoteListPage : ContentPage
	{
		public QuoteListPage ()
		{
			InitializeComponent ();
		}
	}
}

