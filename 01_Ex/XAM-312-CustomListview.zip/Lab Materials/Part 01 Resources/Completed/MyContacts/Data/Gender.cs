namespace MyContacts
{
	public enum Gender { Male, Female };
    
}
