﻿using Xamarin.Forms;

namespace FunFlacts.Effects
{
    public class UnderlineEffect : RoutingEffect
    {
        public UnderlineEffect() : base(typeof(UnderlineEffect).FullName)
        {
        }
    }
}
