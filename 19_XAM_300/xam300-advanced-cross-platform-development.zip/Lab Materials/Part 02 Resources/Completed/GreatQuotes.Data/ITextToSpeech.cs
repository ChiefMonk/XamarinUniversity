﻿namespace GreatQuotes
{
    public interface ITextToSpeech
    {
        void Speak(string text);
    }
}
